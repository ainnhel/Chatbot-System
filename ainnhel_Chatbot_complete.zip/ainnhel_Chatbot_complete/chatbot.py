from trainerbot import trainerbot

def chatMenu():
    print("you may want to ask:")
    print("[1] Promotion and Voucher")
    print("[2] Return and Refund")
    print("[3] Logistics")
    print("[4] Credits")
    print("[5] Quit")

def greetAi():
    print("Enter you're name: ")
    global name
    name = input()
    print("\n")
    print("hello " + str(name) +  " Im you're virtual assistant, how can I help you?")
    chatMenu()
    print("\n")
     
def mainTask():
    while True:
        print("\n")
        userChat = input(str(name) + ": ")

        if userChat == str(1):
            while True:
                print("\n")
                print("Bot: " + "Promotion and Discounts")
                print("[1] Smart Phone")
                print("[2] Shoes")
                print("[3] Computer Desktop")
                print("[4] Laptop")
                print("[5] back")
                print("\n")

                option = input()

                if option == str(1):
                    while True:
                        print("\n" + "Smart Phone:")
                        print("[1] Promotion Deals")
                        print("[2] Trade")
                        print("[3] Discounts")
                        print("\n")

                        optionSmartPhone = input()
                        if optionSmartPhone == str(1):
                            print("Promotion Deals: ")
                            print("[] we have Samsung Galaxy S23 Ultra for 15,000 peso")
                            print("[] we have Apple iPhone 15 pro max for 17,000 peso")
                            print("[] we have Oppo A95 for 14,000 peso")
                            break

                        elif optionSmartPhone == str(2):
                            print("Trade: ")
                            print("[] you can get 1,000 peso discount on Samsung Galaxy S23 Ultra, if you trade-in you're old Samsung Phone")
                            print("[] you can get 1,500 peso discount on iPhone 15 pro max, if you trade-in you're old Apple Phone")
                            print("[] you can get 2,000 peso discount on Oppo A95, if you trade-in you're old Oppo Phone")
                            break

                        elif optionSmartPhone == str(3):
                            print("Discounts: ")
                            print("[] you can get 500 peso discount on Samsung Galaxy S23 Ultra, if you pre-order today")
                            print("[] you can get 600 peso discount on iPhone 15 pro max, if you pre-order today")
                            print("[] you can get 700 peso discount on Oppo A95, if you pre-order today")
                            break



                elif option == str(2):
                    while True:
                        print("\n" + "Shoes:")
                        print("[1] Promotion Deals")
                        print("[2] discounts")
                        print("\n")

                        optionShoe = input()
                        if optionShoe == str(1):
                            print("Promotion Deals: ")
                            print("[] we have Jordan Shoe for 2,000 peso")
                            print("[] we have Adidas Shoe for 1,800 centavo")
                            print("[] we have Nike Shoe for 5,000 peso")
                            break

                        elif optionShoe == str(2):
                            print("Discounts: ")
                            print("[] you can get 100 peso discount on Jordan Shoe, if you pre-order today")
                            print("[] you can get 200 peso discount on Adidas Shoe, if you pre-order today")
                            print("[] you can get 300 peso discount on Nike Shoe, if you pre-order today")
                            break

                elif option == str(3):
                    while True:
                        print("\n" + "Computer Desktop:")
                        print("[1] Promotion Deals")
                        print("[2] discounts")
                        print("\n")
                        
                        optionDesktop = input()
                        if optionDesktop == str(1):
                            print("Promotion Deals: ")
                            print("[] we have MSI Desktop Computer for 20,000 peso")
                            print("[] we have Dell Desktop Computer for 17,000 peso")
                            print("[] we have Asus Desktop Computer for 18,000 peso")
                            break

                        elif optionDesktop == str(2):
                            print("Discounts: ")
                            print("[] you can get 5,000 peso discount on MSI Desktop Computer, if you pre-order today")
                            print("[] you can get 6,000 peso discount on Dell Desktop Computer, if you pre-order today")
                            print("[] you can get 7,000 peso discount on Asus Desktop Computer, if you pre-order today")
                            break

                elif option == str(4):
                    while True:
                        print("\n" + "Laptop:")
                        print("[1] Promotion Deals")
                        print("[2] discounts")
                        print("\n")
                        
                        optionLaptop = input()
                        if optionLaptop == str(1):
                            print("Promotion Deals: ")
                            print("[] we have MSI Laptop for 21,000 peso")
                            print("[] we have Acer Laptop for 18,000 peso")
                            print("[] we have Asus Laptop for 16,000 peso")
                            break

                        elif optionLaptop == str(2):
                            print("Discounts: ")
                            print("[] you can get 5,500 peso discount on MSI Laptop, if you pre-order today")
                            print("[] you can get 6,500 peso discount on Acer Laptop, if you pre-order today")
                            print("[] you can get 7,500 peso discount on Asus Laptop, if you pre-order today")
                            break

                elif option == str(5):
                    print("\n" + "back")
                    chatMenu()
                    break


                
            
        elif userChat == str(2):
            while True:
                print("\n")
                print("Bot: " + "Return and Refund")
                print("[1] Smart Phone")
                print("[2] Shoes")
                print("[3] Computer Desktop")
                print("[4] Laptop")
                print("[5] back")
                print("\n")

                optionTwo = input()

                #Smart Phone
                if optionTwo == str(1):
                    while True:
                        print("Smart Phone")
                        print("[1] Return")
                        print("[2] Refund")
                        
                        RROption = input()

                        #Smart Phone Return
                        if RROption == str(1):
                            print("Brands of Smart Phone")
                            print("[1] Samsung")
                            print("[2] Apple")
                            print("[3] Oppo")

                            brandOption = input()

                            if brandOption == str(1):
                                print("You request to return the Samsung Smart Phone, wait for the Logistic Services to pickup the product.")
                                print("\n")
                                break
                            
                            elif brandOption == str(2):
                                print("You request to return the Apple Smart Phone, wait for the Logistic Services to pickup the product.")
                                print("\n")
                                break

                            elif brandOption == str(3):
                                print("You request to return the Oppo Smart Phone, wait for the Logistic Services to pickup the product.")
                                print("\n")
                                break

                        #Smart Phone Refund
                        elif RROption == str(2):
                            print("Brands of Smart Phone")
                            print("[1] Samsung")
                            print("[2] Apple")
                            print("[3] Oppo")

                            brandOption = input()

                            if brandOption == str(1):
                                print("You money will be refunded and apply to you're bank account, if the Samsung Smart Phone has been verify by the seller.")
                                print("\n")
                                break
                            
                            elif brandOption == str(2):
                                print("You money will be refunded and apply to you're bank account, if the Apple Smart Phone has been verify by the seller.")
                                print("\n")
                                break

                            elif brandOption == str(3):
                                print("You money will be refunded and apply to you're bank account, if the Oppo Smart Phone has been verify by the seller.")
                                print("\n")
                                break
                
                #Shoe
                elif optionTwo == str(2):
                    while True:
                        print("Shoes")
                        print("[1] Return")
                        print("[2] Refund")
                        
                        RROption = input()

                        #Shoe Return
                        if RROption == str(1):
                            print("Brands of Shoes")
                            print("[1] Jordan Shoe")
                            print("[2] Adidas Shoe")
                            print("[3] Nike Shoe")

                            brandOption = input()

                            if brandOption == str(1):
                                print("You request to return the Jordan Shoe, wait for the Logistic Services to pickup the product.")
                                print("\n")
                                break

                            elif brandOption == str(2):
                                print("You request to return the Adidas Shoe, wait for the Logistic Services to pickup the product.")
                                print("\n")
                                break

                            elif brandOption == str(3):
                                print("You request to return the Nike Shoe, wait for the Logistic Services to pickup the product.")
                                print("\n")
                                break
                        
                        #Shoe Refund
                        elif RROption == str(2):
                            print("Brands of Shoes")
                            print("[1] Jordan Shoe")
                            print("[2] Adidas Shoe")
                            print("[3] Nike Shoe")

                            brandOption = input()

                            if brandOption == str(1):
                                print("You money will be refunded and apply to you're bank account, if the Jordan Shoe has been verify by the seller.")
                                print("\n")
                                break
                            
                            elif brandOption == str(2):
                                print("You money will be refunded and apply to you're bank account, if the Adidas Shoe has been verify by the seller.")
                                print("\n")
                                break

                            elif brandOption == str(3):
                                print("You money will be refunded and apply to you're bank account, if the Nike Shoe has been verify by the seller.")
                                print("\n")
                                break

                #Computer Desktop            
                elif optionTwo == str(3):
                    while True:
                        print("Computer Desktop")
                        print("[1] Return")
                        print("[2] Refund")
                        
                        RROption = input()

                        #Computer Desktop Return
                        if RROption == str(1):
                            print("Brands of Computer Desktop")
                            print("[1] MSI")
                            print("[2] Dell")
                            print("[3] Asus")

                            brandOption = input()

                            if brandOption == str(1):
                                print("You request to return the MSI Computer Desktop, wait for the Logistic Services to pickup the product.")
                                print("\n")
                                break
                            
                            elif brandOption == str(2):
                                print("You request to return the Dell Computer Desktop, wait for the Logistic Services to pickup the product.")
                                print("\n")
                                break

                            elif brandOption == str(3):
                                print("You request to return the Asus Computer Desktop, wait for the Logistic Services to pickup the product.")
                                print("\n")
                                break

                        #Computer Desktop Refund
                        elif RROption == str(2):
                            print("Brands of Computer Desktop")
                            print("[1] MSI")
                            print("[2] Dell")
                            print("[3] Asus")

                            brandOption = input()

                            if brandOption == str(1):
                                print("You money will be refunded and apply to you're bank account, if the MSI Computer Desktop has been verify by the seller.")
                                print("\n")
                                break
                            
                            elif brandOption == str(2):
                                print("You money will be refunded and apply to you're bank account, if the Dell Computer Desktop has been verify by the seller.")
                                print("\n")
                                break

                            elif brandOption == str(3):
                                print("You money will be refunded and apply to you're bank account, if the Asus Computer Desktop has been verify by the seller.")
                                print("\n")
                                break
                
                #Laptop
                elif optionTwo == str(4):
                    while True:
                        print("Laptop")
                        print("[1] Return")
                        print("[2] Refund")
                        
                        RROption = input()

                        #Laptop Return
                        if RROption == str(1):
                            print("Brands of Laptop")
                            print("[1] MSI")
                            print("[2] ACER")
                            print("[3] ASUS")

                            brandOption = input()

                            if brandOption == str(1):
                                print("You request to return the MSI Laptop, wait for the Logistic Services to pickup the product.")
                                print("\n")
                                break
                            
                            elif brandOption == str(2):
                                print("You request to return the ACER Laptop, wait for the Logistic Services to pickup the product.")
                                print("\n")
                                break

                            elif brandOption == str(3):
                                print("You request to return the ASUS, wait for the Logistic Services to pickup the product.")
                                print("\n")
                                break

                        #Laptop Refund
                        elif RROption == str(2):
                            print("Brands of Laptop")
                            print("[1] MSI")
                            print("[2] ACER")
                            print("[3] ASUS")

                            brandOption = input()

                            if brandOption == str(1):
                                print("You money will be refunded and apply to you're bank account, if the MSI Laptop has been verify by the seller.")
                                print("\n")
                                break
                            
                            elif brandOption == str(2):
                                print("You money will be refunded and apply to you're bank account, if the ACER Laptop has been verify by the seller.")
                                print("\n")
                                break

                            elif brandOption == str(3):
                                print("You money will be refunded and apply to you're bank account, if the Asus Laptop has been verify by the seller.")
                                print("\n")
                                break
                
                #back
                elif optionTwo == str(5):
                    print("back")
                    chatMenu()
                    break
                    


        elif userChat == str(3):
            while True:
                print("Bot: " + "Logistics")
                print("[1] J & T Express")
                print("[2] Shopee EXpress")
                print("[3] back")

                Loption = input()

                if Loption == str(1):
                    print("You have been Selected J & T Express as you're Logistic Service")
                    print("\n")
                    chatMenu()
                    break
                
                elif Loption == str(2):
                    print("You have been Selected Shopee Express as you're Logistic Service")
                    print("\n")
                    chatMenu()
                    break

                elif Loption == str(3):
                    print("\n" + "back")
                    chatMenu()
                    break
            
        elif userChat == str(4):
            print("Bot: " + "Credits")
            print("Leader: Ainnhel-Keyrt A. Ciego")
            print("Members:")
            print("Eggy Ladiao")
            print("Charles Almonte")
            print("Earl Buscagan")
            print("Earvin Joshua Torrate")
            print("James Burce")
            print("Zion Pormalejo")
            print("Jin Dela Cuesta")
            print("Joseph Leonardo")
            print("\n")

            chatMenu()
            

        elif userChat == str(5):
            print("Bot: " + "closing the program.......")
            break

        elif userChat.startswith("teach"):
            userChat = userChat.replace("teach", "").strip()
            dictionary_data = input("Bot: " + "What is " + userChat + "? ")
            trainerbot.update_data(userChat, dictionary_data)

        else:
            response = trainerbot.generate_response(userChat)
            print("Bot: " + response)
    
greetAi()
mainTask()