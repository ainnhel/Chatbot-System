import json
import os
import random

data_storage = "learnData.json"

if os.path.exists(data_storage):
    database = open("learnData.json", "r")
    data = json.load(database)

else:
    print("the database is offline")
    exit()

class trainerbot:
    
    def compare(words, dictionary_data):
        union = len(set(words) & set(dictionary_data["patterns"]))
        score = union / (len(words) + len(dictionary_data["patterns"]))

        return score

    def match_finder(words):
        best_dictionary_data = None
        best_score = 0
        for dictionary_data in data["learn_key"]:
            score = trainerbot.compare(words, dictionary_data)
            if score > best_score:
                best_dictionary_data = dictionary_data
                best_score = score

        return best_dictionary_data

    def generate_response(userChat):

        words = userChat.lower().split()  
        dictionary_data = trainerbot.match_finder(words)

        if dictionary_data:
            response = random.choice(dictionary_data["responses"])
        else:
            response = "I'm sorry, I don't understand what is " + userChat + " Can you please teach me about " + userChat

        return response

    def update_data(userChat, dictionary_data):
        if dictionary_data not in [i["tag"] for i in data["learn_key"]]:
            data["learn_key"].append({"tag": dictionary_data, "patterns": userChat.lower().split(), "responses": []})
        else:
            index = [i["tag"] for i in data["learn_key"]].index(dictionary_data)

            for word in userChat.lower().split():
                if word not in data["learn_key"][index]["patterns"]:
                    data["learn_key"][index]["patterns"].append(word)

            response = input("Bot: " + "What would be a good response for the data " + userChat + "? ")

            if response not in data["learn_key"][index]["responses"]:
                data["learn_key"][index]["responses"].append(response)

        database = open("learnData.json", "w")
        json.dump(data, database, indent=4)
        print("Your input and dictionary_data have been stored in the database.")