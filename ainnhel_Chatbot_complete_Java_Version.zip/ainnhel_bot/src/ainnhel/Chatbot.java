package ainnhel;

import java.util.Scanner;

public class Chatbot extends Trainerbot {
	
	static Scanner scanner = new Scanner(System.in);
	static String name;
	
	public Chatbot() {
		name = name;
		
	}
	
	public Chatbot(String name) {
		this.name = name;
	}
	

	public static void chatMenu() {
        System.out.println("you may want to ask:");
        System.out.println("[1] Promotion and Voucher");
        System.out.println("[2] Return and Refund");
        System.out.println("[3] Logistics");
        System.out.println("[4] Credits");
        System.out.println("[5] Quit");
    }
	
	public static void greetAi() {
        
        System.out.println("Enter your name: ");
        name = scanner.next();
        System.out.println("\n");
        System.out.println("Hello " + name + " I'm your virtual assistant, how can I help you?");
        chatMenu();
        System.out.println("\n");
    }

	public static void main(String[] args) {
		
		Chatbot object = new Chatbot();
		greetAi();
		
		while (true) {
            System.out.println("\n");
			System.out.print(object.name + ": ");
            String userChat = scanner.next();
            
                        
            if (userChat.equals("1")) {
            	while (true) {
            		System.out.println("\n");
                    System.out.println("Bot: Promotion and Discounts");
                    System.out.println("[1] Smart Phone");
                    System.out.println("[2] Shoes");
                    System.out.println("[3] Computer Desktop");
                    System.out.println("[4] Laptop");
                    System.out.println("[5] back");
                    System.out.println("\n");
                    
                    String option = scanner.next();
                    
                    //SmartPhone
                    if (option.equals("1")) {
                        while (true) {
                            System.out.println("\nSmart Phone:");
                            System.out.println("[1] Promotion Deals");
                            System.out.println("[2] Trade");
                            System.out.println("[3] Discounts\n");

                            String optionSmartPhone = scanner.next();
                            if (optionSmartPhone.equals("1")) {
                                System.out.println("Promotion Deals: ");
                                System.out.println("[] we have Samsung Galaxy S23 Ultra for 15,000 peso");
                                System.out.println("[] we have Apple iPhone 15 pro max for 17,000 peso");
                                System.out.println("[] we have Oppo A95 for 14,000 peso");
                                break;
                            } else if (optionSmartPhone.equals("2")) {
                                System.out.println("Trade: ");
                                System.out.println("[] you can get 1,000 peso discount on Samsung Galaxy S23 Ultra, if you trade-in you're old Samsung Phone");
                                System.out.println("[] you can get 1,500 peso discount on iPhone 15 pro max, if you trade-in you're old Apple Phone");
                                System.out.println("[] you can get 2,000 peso discount on Oppo A95, if you trade-in you're old Oppo Phone");
                                break;
                            } else if (optionSmartPhone.equals("3")) {
                                System.out.println("Discounts: ");
                                System.out.println("[] you can get 500 peso discount on Samsung Galaxy S23 Ultra, if you pre-order today");
                                System.out.println("[] you can get 600 peso discount on iPhone 15 pro max, if you pre-order today");
                                System.out.println("[] you can get 700 peso discount on Oppo A95, if you pre-order today");
                                break;
                            }
                            
                        }//end of while
                    }//end of if Smartphone
                    
                    //Shoes
                    if (option.equals("2")) {
                        while (true) {
                            System.out.println("\nShoes:");
                            System.out.println("[1] Promotion Deals");
                            System.out.println("[2] discounts\n");

                            String optionShoe = scanner.next();
                            if (optionShoe.equals("1")) {
                                System.out.println("Promotion Deals: ");
                                System.out.println("[] we have Jordan Shoe for 2,000 peso");
                                System.out.println("[] we have Adidas Shoe for 1,800 centavo");
                                System.out.println("[] we have Nike Shoe for 5,000 peso");
                                break;
                            } else if (optionShoe.equals("2")) {
                                System.out.println("Discounts: ");
                                System.out.println("[] you can get 100 peso discount on Jordan Shoe, if you pre-order today");
                                System.out.println("[] you can get 200 peso discount on Adidas Shoe, if you pre-order today");
                                System.out.println("[] you can get 300 peso discount on Nike Shoe, if you pre-order today");
                                break;
                            }//end of if
                        }//end of while
                    }//end of if shoes
                    
                    //Computer Desktop
                    if (option.equals("3")) {
                        while (true) {
                            System.out.println("\nComputer Desktop:");
                            System.out.println("[1] Promotion Deals");
                            System.out.println("[2] discounts\n");

                            String optionDesktop = scanner.next();
                            if (optionDesktop.equals("1")) {
                                System.out.println("Promotion Deals: ");
                                System.out.println("[] we have MSI Desktop Computer for 20,000 peso");
                                System.out.println("[] we have Dell Desktop Computer for 17,000 peso");
                                System.out.println("[] we have Asus Desktop Computer for 18,000 peso");
                                break;
                            } else if (optionDesktop.equals("2")) {
                                System.out.println("Discounts: ");
                                System.out.println("[] you can get 5,000 peso discount on MSI Desktop Computer, if you pre-order today");
                                System.out.println("[] you can get 6,000 peso discount on Dell Desktop Computer, if you pre-order today");
                                System.out.println("[] you can get 7,000 peso discount on Asus Desktop Computer, if you pre-order today");
                                break;
                            }
                        }//end of while
                    }// end of if Computer Desktop
                    
                    //Laptop
                    if (option.equals("4")) {
                        while (true) {
                            System.out.println("\nLaptop:");
                            System.out.println("[1] Promotion Deals");
                            System.out.println("[2] discounts\n");

                            String optionLaptop = scanner.next();
                            if (optionLaptop.equals("1")) {
                                System.out.println("Promotion Deals: ");
                                System.out.println("[] we have MSI Laptop for 21,000 peso");
                                System.out.println("[] we have Acer Laptop for 18,000 peso");
                                System.out.println("[] we have Asus Laptop for 16,000 peso");
                                break;
                            } else if (optionLaptop.equals("2")) {
                                System.out.println("Discounts: ");
                                System.out.println("[] you can get 5,500 peso discount on MSI Laptop, if you pre-order today");
                                System.out.println("[] you can get 6,500 peso discount on Acer Laptop, if you pre-order today");
                                System.out.println("[] you can get 7,500 peso discount on Asus Laptop, if you pre-order today");
                                break;
                            }
                        }//end of while
                    }//end of if laptop
                    
                    //back
                    if (option.equals("5")) {
                        System.out.println("\n" + "back");
                        chatMenu();
                        break;
                    }
                    
                    
            		
            	}//end of while loop
            	
            }//end of if Promotion and discounts
            
            //Return and Refund
            if (userChat.equals("2")) {
                while (true) {
                    System.out.println();
                    System.out.println("Bot: " + "Return and Refund");
                    System.out.println("[1] Smart Phone");
                    System.out.println("[2] Shoes");
                    System.out.println("[3] Computer Desktop");
                    System.out.println("[4] Laptop");
                    System.out.println("[5] back");
                    System.out.println();
                    
                    String optionTwo = scanner.next();

                  //Smart Phone Return and Refund
                  if (optionTwo.equals("1")) {
                      while (true) {
                          System.out.println("Smart Phone");
                          System.out.println("[1] Return");
                          System.out.println("[2] Refund");
                          
                          String RROption = scanner.next();

                          //Smart Phone Return
                          if (RROption.equals("1")) {
                              System.out.println("Brands of Smart Phone");
                              System.out.println("[1] Samsung");
                              System.out.println("[2] Apple");
                              System.out.println("[3] Oppo");

                              String brandOption = scanner.next();

                              if (brandOption.equals("1")) {
                                  System.out.println("You request to return the Samsung Smart Phone, wait for the Logistic Services to pickup the product.");
                                  System.out.println();
                                  break;
                              }
                              
                              else if (brandOption.equals("2")) {
                                  System.out.println("You request to return the Apple Smart Phone, wait for the Logistic Services to pickup the product.");
                                  System.out.println();
                                  break;
                              }

                              else if (brandOption.equals("3")) {
                                  System.out.println("You request to return the Oppo Smart Phone, wait for the Logistic Services to pickup the product.");
                                  System.out.println();
                                  break;
                              }
                          }//end of if smart phone return
                          
                        //Smart Phone Refund
                          else if (RROption.equals("2")) {
                              System.out.println("Brands of Smart Phone");
                              System.out.println("[1] Samsung");
                              System.out.println("[2] Apple");
                              System.out.println("[3] Oppo");

                              String brandOption = scanner.next();

                              if (brandOption.equals("1")) {
                                  System.out.println("Your money will be refunded and applied to your bank account, if the Samsung Smart Phone has been verified by the seller.");
                                  System.out.println();
                                  break;
                              }
                              
                              else if (brandOption.equals("2")) {
                                  System.out.println("Your money will be refunded and applied to your bank account, if the Apple Smart Phone has been verified by the seller.");
                                  System.out.println();
                                  break;
                              }

                              else if (brandOption.equals("3")) {
                                  System.out.println("Your money will be refunded and applied to your bank account, if the Oppo Smart Phone has been verified by the seller.");
                                  System.out.println();
                                  break;
                              }
                          }//end of if Smart Phone Refund
                          
                          
                      }//end of while
                  }//end of if Smart Phone Return and Refund
                  
                  //Shoe
                  else if (optionTwo.equals("2")) {
                	  while (true) {
                		  System.out.println ("Shoes");
                		  System.out.println ("[1] Return");
                		  System.out.println ("[2] Refund");
                		  
                		  String RROption = scanner.next();
                		  
                		  // Shoe Return
                		  if (RROption.equals("1")) {
                		    System.out.println("Brands of Shoes");
                		    System.out.println("[1] Jordan Shoe");
                		    System.out.println("[2] Adidas Shoe");
                		    System.out.println("[3] Nike Shoe");

                		    String brandOption = scanner.next();

                		    if (brandOption.equals("1")) {
                		      System.out.println("You request to return the Jordan Shoe, wait for the Logistic Services to pickup the product.");
                		      System.out.println();
                		      break;
                		    }

                		    else if (brandOption.equals("2")) {
                		      System.out.println("You request to return the Adidas Shoe, wait for the Logistic Services to pickup the product.");
                		      System.out.println();
                		      break;
                		    }

                		    else if (brandOption.equals("3")) {
                		      System.out.println("You request to return the Nike Shoe, wait for the Logistic Services to pickup the product.");
                		      System.out.println();
                		      break;
                		    }
                		  }//end of if shoe return
                		  
                		  // Shoe Refund
                		  else if (RROption.equals("2")) {
                		      System.out.println("Brands of Shoes");
                		      System.out.println("[1] Jordan Shoe");
                		      System.out.println("[2] Adidas Shoe");
                		      System.out.println("[3] Nike Shoe");

                		      String brandOption = scanner.next();

                		      if (brandOption.equals("1")) {
                		          System.out.println("You money will be refunded and apply to your bank account, if the Jordan Shoe has been verified by the seller.");
                		          System.out.println("\n");
                		          break;
                		      }
                		      else if (brandOption.equals("2")) {
                		          System.out.println("You money will be refunded and apply to your bank account, if the Adidas Shoe has been verified by the seller.");
                		          System.out.println("\n");
                		          break;
                		      }
                		      else if (brandOption.equals("3")) {
                		          System.out.println("You money will be refunded and apply to your bank account, if the Nike Shoe has been verified by the seller.");
                		          System.out.println("\n");
                		          break;
                		      }
                		  }//end of if shoe refund
                		  
                		}//end of while
                	}//end of if shoe Return and refund
                  
                  
                  // Computer Desktop
                  else if (optionTwo.equals("3")) {
                	  while (true) {
                		    System.out.println("Computer Desktop");
                		    System.out.println("[1] Return");
                		    System.out.println("[2] Refund");

                		    String RROption = scanner.next();

                		    // Computer Desktop Return
                		    if (RROption.equals("1")) {
                		        System.out.println("Brands of Computer Desktop");
                		        System.out.println("[1] MSI");
                		        System.out.println("[2] Dell");
                		        System.out.println("[3] Asus");

                		        String brandOption = scanner.next();

                		        if (brandOption.equals("1")) {
                		            System.out.println("You request to return the MSI Computer Desktop, wait for the Logistic Services to pickup the product.");
                		            System.out.println("\n");
                		            break;
                		        }
                		        else if (brandOption.equals("2")) {
                		            System.out.println("You request to return the Dell Computer Desktop, wait for the Logistic Services to pickup the product.");
                		            System.out.println("\n");
                		            break;
                		        }
                		        else if (brandOption.equals("3")) {
                		            System.out.println("You request to return the Asus Computer Desktop, wait for the Logistic Services to pickup the product.");
                		            System.out.println("\n");
                		            break;
                		        }
                		    }//end of if Computer Desktop Return
                		    
                		 // Computer Desktop Refund
                		    else if (RROption.equals("2")) {
                		        System.out.println("Brands of Computer Desktop");
                		        System.out.println("[1] MSI");
                		        System.out.println("[2] Dell");
                		        System.out.println("[3] Asus");

                		        String brandOption = scanner.next();

                		        if (brandOption.equals("1")) {
                		            System.out.println("Your money will be refunded and applied to your bank account, if the MSI Computer Desktop has been verified by the seller.");
                		            System.out.println("\n");
                		            break;
                		        }
                		        else if (brandOption.equals("2")) {
                		            System.out.println("Your money will be refunded and applied to your bank account, if the Dell Computer Desktop has been verified by the seller.");
                		            System.out.println("\n");
                		            break;
                		        }
                		        else if (brandOption.equals("3")) {
                		            System.out.println("Your money will be refunded and applied to your bank account, if the Asus Computer Desktop has been verified by the seller.");
                		            System.out.println("\n");
                		            break;
                		        }
                		    }//end of if Computer Desktop Refund
                		    
                		    
                		}//end of while computer desktop
                  }//end of if Computer Desktop Return and refund
                  
                  //Laptop
                  else if (optionTwo.equals("4")) {
                	  while (true) {
                		    System.out.println("Laptop");
                		    System.out.println("[1] Return");
                		    System.out.println("[2] Refund");

                		    String RROption = scanner.next();

                		    // Laptop Return
                		    if (RROption.equals("1")) {
                		        System.out.println("Brands of Laptop");
                		        System.out.println("[1] MSI");
                		        System.out.println("[2] ACER");
                		        System.out.println("[3] ASUS");

                		        String brandOption = scanner.next();

                		        if (brandOption.equals("1")) {
                		            System.out.println("You request to return the MSI Laptop, wait for the Logistic Services to pickup the product.");
                		            System.out.println("\n");
                		            break;
                		        }
                		        else if (brandOption.equals("2")) {
                		            System.out.println("You request to return the ACER Laptop, wait for the Logistic Services to pickup the product.");
                		            System.out.println("\n");
                		            break;
                		        }
                		        else if (brandOption.equals("3")) {
                		            System.out.println("You request to return the ASUS Laptop, wait for the Logistic Services to pickup the product.");
                		            System.out.println("\n");
                		            break;
                		        }
                		    }// end of Laptop Return
                		    
                		    // Laptop Refund
                		    else if (RROption.equals("2")) {
                		        System.out.println("Brands of Laptop");
                		        System.out.println("[1] MSI");
                		        System.out.println("[2] ACER");
                		        System.out.println("[3] ASUS");

                		        String brandOption = scanner.next();

                		        if (brandOption.equals("1")) {
                		            System.out.println("Your money will be refunded and applied to your bank account, if the MSI Laptop has been verified by the seller.");
                		            System.out.println("\n");
                		            break;
                		        }
                		        else if (brandOption.equals("2")) {
                		            System.out.println("Your money will be refunded and applied to your bank account, if the ACER Laptop has been verified by the seller.");
                		            System.out.println("\n");
                		            break;
                		        }
                		        else if (brandOption.equals("3")) {
                		            System.out.println("Your money will be refunded and applied to your bank account, if the ASUS Laptop has been verified by the seller.");
                		            System.out.println("\n");
                		            break;
                		        }
                		    }//end of Laptop Refund
                		    
                		}//end of while
                  }//end of if Laptop Return and refund
                  
                  // back
                  else if (optionTwo.equals("5")) {
                      System.out.println("back");
                      chatMenu();
                      break;
                  }//enfd of if back
                 
                }//end of while
            }//end of if Return and refund
            
            //Logistics
            else if (userChat.equals("3")) {
                while (true) {
                    System.out.println("Bot: Logistics");
                    System.out.println("[1] J & T Express");
                    System.out.println("[2] Shopee Express");
                    System.out.println("[3] back");

                    Scanner scanner = new Scanner(System.in);
                    String Loption = scanner.next();

                    if (Loption.equals("1")) {
                        System.out.println("You have been Selected J & T Express as you're Logistic Service");
                        System.out.println();
                        chatMenu();
                        break;
                    } else if (Loption.equals("2")) {
                        System.out.println("You have been Selected Shopee Express as you're Logistic Service");
                        System.out.println();
                        chatMenu();
                        break;
                    } else if (Loption.equals("3")) {
                        System.out.println("back");
                        chatMenu();
                        break;
                    }
                }//end of while
            }//end of Logistics
            
            //Credits
            if (userChat.equals("4")) {
                System.out.println("Bot: Credits");
                System.out.println("Leader: Ainnhel-Keyrt A. Ciego");
                System.out.println("Members:");
                System.out.println("Eggy Ladiao");
                System.out.println("Charles Almonte");
                System.out.println("Earl Buscagan");
                System.out.println("Earvin Joshua Torrate");
                System.out.println("James Burce");
                System.out.println("Zion Pormalejo");
                System.out.println("Jin Dela Cuesta");
                System.out.println("Joseph Leonardo");
                System.out.println();

                chatMenu();
            }//end of if credits
            
            //exit
            else if (userChat.equals("5")) {
                System.out.println("Bot: closing the program.......");
                break;
            }
            
            
            else if (userChat.startsWith("teach")) {
                userChat = userChat.replace("teach", "").trim();
                System.out.print("Bot: What is " + userChat + "? ");
                Scanner scanner = new Scanner(System.in);
                String dictionaryData = scanner.nextLine();
                Trainerbot.updateData(userChat, dictionaryData);
            }
            
            else {
                String response = Trainerbot.generateResponse(userChat);
                System.out.println("Bot: " + response);
            }
            
            

		}//end of while main
	}//end of main method

}//end of chatbot class
