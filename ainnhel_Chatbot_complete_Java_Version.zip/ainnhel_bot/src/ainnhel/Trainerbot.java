package ainnhel;

import com.google.gson.*;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;



public class Trainerbot {
	
	private static String dataStorage = "learnData.json";
    private static Map<String, Object> data;

    static {
        try {
            File file = new File(dataStorage);
            if (file.exists()) {
                BufferedReader reader = new BufferedReader(new FileReader(file));
                data = new Gson().fromJson(reader, new TypeToken<Map<String, Object>>(){}.getType());
                reader.close();
            } else {
                System.out.println("The database is offline");
                System.exit(0);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static double compare(List<String> words, Map<String, Object> dictionaryData) {
        Set<String> union = new HashSet<>(words);
        union.retainAll((List<String>) dictionaryData.get("patterns"));
        double score = (double) union.size() / (words.size() + ((List<String>) dictionaryData.get("patterns")).size());

        return score;
    }

    public static Map<String, Object> matchFinder(List<String> words) {
        Map<String, Object> bestDictionaryData = null;
        double bestScore = 0;
        for (Map<String, Object> dictionaryData : (List<Map<String, Object>>) data.get("learn_key")) {
            double score = compare(words, dictionaryData);
            if (score > bestScore) {
                bestDictionaryData = dictionaryData;
                bestScore = score;
            }
        }

        return bestDictionaryData;
    }

    public static String generateResponse(String userChat) {
        List<String> words = Arrays.asList(userChat.toLowerCase().split("\\s+"));
        Map<String, Object> dictionaryData = matchFinder(words);
        String response;

        if (dictionaryData != null) {
            List<String> responses = (List<String>) dictionaryData.get("responses");
            response = responses.get(new Random().nextInt(responses.size()));
        } else {
            response = "I'm sorry, I don't understand what is " + userChat + ". Can you please teach me about " + userChat;
        }

        return response;
    }

    public static void updateData(String userChat, String dictionaryData) {
        List<Map<String, Object>> learnKey = (List<Map<String, Object>>) data.get("learn_key");
        List<String> tags = new ArrayList<>();
        for (Map<String, Object> item : learnKey) {
            tags.add((String) item.get("tag"));
        }

        if (!tags.contains(dictionaryData)) {
            Map<String, Object> newItem = new HashMap<>();
            newItem.put("tag", dictionaryData);
            newItem.put("patterns", Arrays.asList(userChat.toLowerCase().split("\\s+")));
            newItem.put("responses", new ArrayList<>());
            learnKey.add(newItem);
        } else {
            int index = tags.indexOf(dictionaryData);
            Map<String, Object> item = learnKey.get(index);
            List<String> words = Arrays.asList(userChat.toLowerCase().split("\\s+"));
            List<String> patterns = (List<String>) item.get("patterns");

            for (String word : words) {
                if (!patterns.contains(word)) {
                    patterns.add(word);
                }
            }

            System.out.print("Bot: What would be a good response for the data " + userChat + "? ");
            Scanner scanner = new Scanner(System.in);
            String response = scanner.nextLine();
            List<String> responses = (List<String>) item.get("responses");

            if (!responses.contains(response)) {
                responses.add(response);
            }

            scanner.close();
        }

        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(dataStorage));
            new Gson().toJson(data, writer);
            writer.close();
            System.out.println("Your input and dictionary data have been stored in the database.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
